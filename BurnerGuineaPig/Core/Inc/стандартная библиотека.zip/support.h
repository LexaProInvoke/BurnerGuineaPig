#ifndef __support
#define __support

#include <math.h>
void ftoa(float n, char* res, int afterpoint) ;  // floating/double to string (display on LCD usage)
int intToStr(int x, char str[], int d) ;

#endif